package cliente;

// Clase para arrancar el cliente.
// Si se ejecuta directamente ClienteChat (que extiende Application) sin module-info,
// Java da el error "JavaFX runtime components are missing". Arrancando desde aqui no pasa.
public class Main {

    public static void main(String[] args) {
        ClienteChat.main(args);
    }
}
