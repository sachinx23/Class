package cliente;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

// Hilo que conecta con el servidor y despues se dedica solo a recibir mensajes.
// Asi el hilo de la interfaz (JavaFX) queda libre y la ventana nunca se bloquea,
// ni siquiera mientras se espera a que el servidor responda al conectar.
public class HiloReceptor extends Thread {

    private String ip;
    private int puerto;
    private String nombre;
    private ChatController controlador;

    public HiloReceptor(String ip, int puerto, String nombre, ChatController controlador) {
        this.ip = ip;
        this.puerto = puerto;
        this.nombre = nombre;
        this.controlador = controlador;
    }

    @Override
    public void run() {
        try {
            // 1. Conectar (puede tardar, por eso se hace en este hilo)
            Socket socket = new Socket(ip, puerto);
            ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());

            // Primer mensaje: le decimos al servidor quien somos
            salida.writeObject("NOMBRE:" + nombre);
            salida.flush();
            controlador.conectado(socket, salida);

            // 2. Recibir mensajes. readObject() se bloquea hasta que llega uno
            while (true) {
                String mensaje = (String) entrada.readObject();
                controlador.mensajeRecibido(mensaje);
            }
        } catch (IOException e) {
            // No se pudo conectar, servidor caido o socket cerrado
            controlador.conexionPerdida(e.getMessage());
        } catch (ClassNotFoundException e) {
            controlador.conexionPerdida(e.getMessage());
        }
    }
}
