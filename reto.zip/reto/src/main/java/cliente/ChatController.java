package cliente;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

// Controlador de chat.fxml.
// El envio se hace desde el hilo de la interfaz y la recepcion en un hilo aparte (HiloReceptor).
//
// Los mensajes son Strings con el formato TIPO:datos
//   Cliente -> servidor:  NOMBRE:ana   PUBLICO:texto   PRIVADO:destino:texto   SALIR
//   Servidor -> cliente:  PUBLICO:emisor:texto   PRIVADO:emisor:texto   SERVIDOR:texto   RECHAZO:texto
public class ChatController {

    // Controles definidos en chat.fxml (el nombre coincide con su fx:id)
    @FXML
    private TextField txtIp;
    @FXML
    private TextField txtPuerto;
    @FXML
    private TextField txtUsuario;
    @FXML
    private Button btnConectar;
    @FXML
    private Button btnDesconectar;
    @FXML
    private Label lblEstado;
    @FXML
    private TextArea areaMensajes;
    @FXML
    private CheckBox chkPrivado;
    @FXML
    private TextField txtPara;
    @FXML
    private TextField txtMensaje;
    @FXML
    private Button btnEnviar;

    private Socket socket;
    private ObjectOutputStream salida;
    private String nombre;
    private boolean conectando = false;
    private boolean conectado = false;

    // Boton Conectar
    @FXML
    public void conectar() {
        try {
            String ip = txtIp.getText();
            int puerto = Integer.parseInt(txtPuerto.getText());
            nombre = txtUsuario.getText();

            // La conexion la hace el HiloReceptor, asi la ventana no se bloquea mientras espera
            conectando = true;
            lblEstado.setText("Conectando...");
            btnConectar.setDisable(true);

            HiloReceptor receptor = new HiloReceptor(ip, puerto, nombre, this);
            receptor.setDaemon(true); // si se cierra la ventana, el hilo termina con el programa
            receptor.start();
        } catch (NumberFormatException e) {
            mostrar("El puerto debe ser un numero");
        }
    }

    // Lo llama el HiloReceptor cuando ya se ha conectado al servidor
    public void conectado(final Socket s, final ObjectOutputStream out) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                socket = s;
                salida = out;
                conectando = false;
                conectado = true;
                lblEstado.setText("Conectado como " + nombre);
                btnDesconectar.setDisable(false);
                btnEnviar.setDisable(false);
            }
        });
    }

    // Boton Desconectar (tambien se llama al cerrar la ventana)
    @FXML
    public void desconectar() {
        if (!conectado) {
            return;
        }
        try {
            salida.writeObject("SALIR");
            salida.flush();
        } catch (IOException e) {
        }
        cerrar();
        mostrar("Te has desconectado");
    }

    // Boton Enviar
    @FXML
    public void enviarMensaje() {
        String mensaje;
        if (chkPrivado.isSelected()) {
            mensaje = "PRIVADO:" + txtPara.getText() + ":" + txtMensaje.getText();
        } else {
            mensaje = "PUBLICO:" + txtMensaje.getText();
        }

        try {
            salida.writeObject(mensaje);
            salida.flush();
            txtMensaje.clear();
        } catch (IOException e) {
            mostrar("Error al enviar: " + e.getMessage());
        }
    }

    // Lo llama el HiloReceptor. El hilo receptor no puede tocar la interfaz,
    // por eso se usa Platform.runLater: el codigo se ejecuta en el hilo de JavaFX.
    public void mensajeRecibido(final String mensaje) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if (mensaje.startsWith("PUBLICO:")) {
                    // PUBLICO:emisor:texto
                    String[] partes = mensaje.split(":", 3);
                    mostrar("[PUBLICO] " + partes[1] + ": " + partes[2]);
                } else if (mensaje.startsWith("PRIVADO:")) {
                    // PRIVADO:emisor:texto
                    String[] partes = mensaje.split(":", 3);
                    mostrar("[PRIVADO] " + partes[1] + ": " + partes[2]);
                } else if (mensaje.startsWith("SERVIDOR:")) {
                    mostrar("[SERVIDOR] " + mensaje.substring("SERVIDOR:".length()));
                } else if (mensaje.startsWith("RECHAZO:")) {
                    mostrar("[SERVIDOR] Conexion rechazada: " + mensaje.substring("RECHAZO:".length()));
                    cerrar();
                }
            }
        });
    }

    // Lo llama el HiloReceptor si no se pudo conectar o si se pierde la conexion
    public void conexionPerdida(final String error) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if (conectando) {
                    conectando = false;
                    mostrar("Error al conectar: " + error);
                    lblEstado.setText("No conectado");
                    btnConectar.setDisable(false);
                } else if (conectado) {
                    mostrar("Se ha perdido la conexion con el servidor");
                    cerrar();
                }
            }
        });
    }

    private void cerrar() {
        conectado = false;
        try {
            socket.close(); // al cerrar el socket el HiloReceptor sale de readObject()
        } catch (IOException e) {
        }
        lblEstado.setText("No conectado");
        btnConectar.setDisable(false);
        btnDesconectar.setDisable(true);
        btnEnviar.setDisable(true);
    }

    private void mostrar(String texto) {
        areaMensajes.appendText(texto + "\n");
    }
}
