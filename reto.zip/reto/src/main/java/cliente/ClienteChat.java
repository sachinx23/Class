package cliente;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

// Aplicacion JavaFX: carga la interfaz desde chat.fxml.
// Toda la logica del chat esta en ChatController.
public class ClienteChat extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("chat.fxml"));
        Parent raiz = loader.load();
        final ChatController controlador = loader.getController();

        // Al cerrar la ventana nos desconectamos del servidor
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent e) {
                controlador.desconectar();
            }
        });

        stage.setTitle("Chat multiusuario");
        stage.setScene(new Scene(raiz));
        stage.show();
    }
}
