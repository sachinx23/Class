package servidor;

import java.util.ArrayList;

// Recurso compartido por todos los hilos del servidor.
// Guarda los usuarios conectados, los mensajes enviados y el log.
// Todos los metodos son synchronized para que dos hilos no los usen a la vez.
public class SalaChat {

    private int maxClientes;
    private ArrayList<HiloCliente> clientes = new ArrayList<HiloCliente>();
    private ArrayList<String> mensajes = new ArrayList<String>();
    private ArrayList<String> log = new ArrayList<String>();
    private String ultimoMensaje = "(ninguno)";
    private long horaInicio;

    public SalaChat(int maxClientes) {
        this.maxClientes = maxClientes;
        this.horaInicio = System.currentTimeMillis();
    }

    // Anade un cliente. Devuelve false si se ha llegado al maximo.
    public synchronized boolean agregarCliente(HiloCliente nuevo) {
        if (clientes.size() >= maxClientes) {
            return false;
        }
        clientes.add(nuevo);
        return true;
    }

    public synchronized void eliminarCliente(HiloCliente cliente) {
        clientes.remove(cliente);
    }

    public synchronized int getNumUsuarios() {
        return clientes.size();
    }

    // Envia un mensaje a todos los usuarios conectados menos al indicado (puede ser null)
    public synchronized void enviarATodos(String mensaje, HiloCliente excluido) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i) != excluido) {
                clientes.get(i).enviar(mensaje);
            }
        }
    }

    // Envia un mensaje solo al usuario indicado
    public synchronized void enviarPrivado(String destinatario, String mensaje) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getNombre().equals(destinatario)) {
                clientes.get(i).enviar(mensaje);
            }
        }
    }

    // Guarda el mensaje en la lista de mensajes enviados
    public synchronized void guardarMensaje(String texto) {
        mensajes.add(texto);
        ultimoMensaje = texto;
    }

    public synchronized String getUltimoMensaje() {
        return ultimoMensaje;
    }

    public long getSegundosActivo() {
        return (System.currentTimeMillis() - horaInicio) / 1000;
    }

    // Log global: guarda la accion y la muestra por consola
    public synchronized void log(String texto) {
        log.add(texto);
        System.out.println("[LOG] " + texto);
    }
}
