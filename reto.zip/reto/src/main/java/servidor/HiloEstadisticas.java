package servidor;

// Hilo que cada X segundos muestra por consola:
// numero de usuarios conectados, tiempo activo del servidor y ultimo mensaje recibido.
public class HiloEstadisticas extends Thread {

    private SalaChat sala;
    private int segundos;

    public HiloEstadisticas(SalaChat sala, int segundos) {
        this.sala = sala;
        this.segundos = segundos;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(segundos * 1000L);
            } catch (InterruptedException e) {
                return;
            }

            long total = sala.getSegundosActivo();
            long horas = total / 3600;
            long minutos = (total % 3600) / 60;
            long seg = total % 60;

            System.out.println("------------ ESTADISTICAS ------------");
            System.out.println("Usuarios conectados: " + sala.getNumUsuarios());
            System.out.println("Tiempo activo: " + horas + "h " + minutos + "m " + seg + "s");
            System.out.println("Ultimo mensaje: " + sala.getUltimoMensaje());
            System.out.println("--------------------------------------");
        }
    }
}
