package servidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

// Hilo que atiende a UN cliente. El servidor crea uno por cada conexion.
//
// Los mensajes son Strings con el formato TIPO:datos
//   Cliente -> servidor:  NOMBRE:ana   PUBLICO:texto   PRIVADO:destino:texto   SALIR
//   Servidor -> cliente:  PUBLICO:emisor:texto   PRIVADO:emisor:texto   SERVIDOR:texto   RECHAZO:texto
public class HiloCliente extends Thread {

    private Socket socket;
    private SalaChat sala;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;
    private String nombre = "";

    public HiloCliente(Socket socket, SalaChat sala) {
        this.socket = socket;
        this.sala = sala;
    }

    public String getNombre() {
        return nombre;
    }

    // Puede llamarse desde varios hilos a la vez (otros clientes reenviando mensajes),
    // por eso es synchronized: asi no se mezclan dos mensajes en el mismo stream.
    public synchronized void enviar(String mensaje) {
        try {
            salida.writeObject(mensaje);
            salida.flush();
        } catch (IOException e) {
            // Si falla, el propio hilo del cliente detectara la desconexion al leer
        }
    }

    @Override
    public void run() {
        boolean registrado = false;
        try {
            salida = new ObjectOutputStream(socket.getOutputStream());
            entrada = new ObjectInputStream(socket.getInputStream());

            // 1. El primer mensaje del cliente trae su nombre: NOMBRE:ana
            String primero = (String) entrada.readObject();
            nombre = primero.substring("NOMBRE:".length());

            // 2. Comprobar el limite de clientes
            if (!sala.agregarCliente(this)) {
                enviar("RECHAZO:Servidor lleno");
                return;
            }
            registrado = true;

            // 3. Log y aviso al resto de usuarios
            sala.log("Entra el usuario " + nombre);
            sala.enviarATodos("SERVIDOR:" + nombre + " se ha conectado", this);

            // 4. Bucle de lectura de mensajes
            boolean seguir = true;
            while (seguir) {
                String mensaje = (String) entrada.readObject();

                if (mensaje.startsWith("PUBLICO:")) {
                    String texto = mensaje.substring("PUBLICO:".length());
                    sala.guardarMensaje(nombre + ": " + texto);
                    sala.log("Mensaje publico de " + nombre + ": " + texto);
                    sala.enviarATodos("PUBLICO:" + nombre + ":" + texto, null);

                } else if (mensaje.startsWith("PRIVADO:")) {
                    // PRIVADO:destino:texto -> partes[0]=PRIVADO, partes[1]=destino, partes[2]=texto
                    String[] partes = mensaje.split(":", 3);
                    String destino = partes[1];
                    String texto = partes[2];
                    sala.guardarMensaje(nombre + " -> " + destino + ": " + texto);
                    sala.log("Mensaje privado de " + nombre + " para " + destino + ": " + texto);
                    sala.enviarPrivado(destino, "PRIVADO:" + nombre + ":" + texto);

                } else if (mensaje.equals("SALIR")) {
                    seguir = false;
                }
            }

        } catch (IOException e) {
            // El cliente cerro la conexion de golpe o hubo un error de red
        } catch (ClassNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            if (registrado) {
                sala.eliminarCliente(this);
                sala.log("Sale el usuario " + nombre);
            }
            try {
                socket.close();
            } catch (IOException e) {
            }
        }
    }
}
