package servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

// Programa principal del servidor (consola).
// Abre el puerto, espera clientes con accept() y crea un hilo por cada cliente.
public class Servidor {

    public static final int PUERTO = 5000;
    public static final int MAX_CLIENTES = 5;
    public static final int SEGUNDOS_ESTADISTICAS = 10;

    public static void main(String[] args) {
        // Objeto compartido por todos los hilos
        SalaChat sala = new SalaChat(MAX_CLIENTES);

        // Hilo que muestra las estadisticas cada X segundos
        HiloEstadisticas estadisticas = new HiloEstadisticas(sala, SEGUNDOS_ESTADISTICAS);
        estadisticas.start();

        try {
            ServerSocket serverSocket = new ServerSocket(PUERTO);
            System.out.println("Servidor escuchando en el puerto " + PUERTO);

            while (true) {
                // accept() se queda bloqueado hasta que llega un cliente
                Socket socketCliente = serverSocket.accept();

                // Un hilo independiente para cada cliente
                HiloCliente hilo = new HiloCliente(socketCliente, sala);
                hilo.start();
            }
        } catch (IOException e) {
            System.out.println("Error en el servidor: " + e.getMessage());
        }
    }
}
